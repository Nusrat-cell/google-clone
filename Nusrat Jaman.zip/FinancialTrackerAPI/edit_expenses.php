<?php
// Start session to access user login information
session_start();

// Check if user is logged in, if not redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection settings
$host = 'localhost';        // Server where database is hosted
$dbname = 'financialtracker'; // Name of the database
$username = 'root';         // Database username  
$password = '';             // Database password

try {
    // Create connection to MySQL database using PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set PDO to throw exceptions on errors for better error handling
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    // Display error message and stop script if connection fails
    die("❌ Connection failed: " . $e->getMessage());
}

// Initialize variable to hold expense data
$expense = null;
// Check if expense ID is provided in URL
if(isset($_GET['id'])) {
    // Prepare SQL query to get specific expense by ID
    $stmt = $pdo->prepare("SELECT * FROM expenses WHERE ExpenseID = ?");
    // Execute query with the ID from URL
    $stmt->execute([$_GET['id']]);
    // Fetch the expense record as associative array
    $expense = $stmt->fetch();
}

// If no expense found with given ID, show error and stop
if(!$expense) {
    die("❌ Expense not found!");
}

// Initialize error message variable
$error = '';
// Check if form was submitted (update button clicked)
if(isset($_POST['update_expense'])) {
    // Get amount from form and convert to number
    $amount = $_POST['amount'];
    // Get vendor name and remove extra spaces
    $vendor = trim($_POST['vendor']);
    // Get date from form input
    $date = $_POST['date_spent'];
    // Get description and remove extra spaces
    $description = trim($_POST['description']);
    
    // Validate that all required fields are filled
    if(empty($amount) || empty($vendor) || empty($date)) {
        $error = "❌ Please fill all required fields!";
    } 
    // Validate that amount is positive number
    elseif($amount <= 0) {
        $error = "❌ Amount must be greater than 0!";
    } 
    // Validate vendor name has at least 2 characters
    elseif(strlen($vendor) < 2) {
        $error = "❌ Vendor must be at least 2 characters!";
    } 
    // Validate date is not in the future
    elseif($date > date('Y-m-d')) {
        $error = "❌ Date cannot be in the future!";
    } else {
        // If all validation passes, try to update database
        try {
            // SQL query to update expense record
            $sql = "UPDATE expenses SET Amount = ?, Vendor = ?, DateSpent = ?, Description = ? WHERE ExpenseID = ?";
            // Prepare the SQL statement
            $stmt = $pdo->prepare($sql);
            
            // Execute update with form values and expense ID
            if($stmt->execute([$amount, $vendor, $date, $description, $_GET['id']])) {
                // Redirect to expenses page with success message
                header("Location: expenses.php?message=updated");
                exit();
            } else {
                // Show error if update failed
                $error = "❌ Error updating expense!";
            }
        } catch (Exception $e) {
            // Show database error message
            $error = "❌ Database error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Basic HTML document setup -->
    <meta charset="UTF-8">  <!-- Character encoding -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  <!-- Responsive design -->
    <title>Edit Expense - Financial Tracker</title>  <!-- Page title -->
    <style>
        /* Reset default browser styles */
        * {
            margin: 0;      /* Remove default margin */
            padding: 0;     /* Remove default padding */
            box-sizing: border-box;  /* Include padding/border in element width */
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;  /* Set font family */
        }

        /* Main page background */
        body {
            background: linear-gradient(135deg, #ff6b6b 0%, #ff8e8e 100%);  /* Red gradient background */
            min-height: 100vh;      /* Full viewport height */
            display: flex;          /* Flexbox for centering */
            align-items: center;    /* Vertical center */
            justify-content: center; /* Horizontal center */
            padding: 20px;          /* Add spacing around edges */
        }

        /* Main content container */
        .container {
            background: rgba(255, 255, 255, 0.95);  /* Semi-transparent white */
            padding: 40px;          /* Inner spacing */
            border-radius: 20px;    /* Rounded corners */
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);  /* Shadow for depth */
            border: 2px solid rgba(255, 107, 107, 0.3);  /* Light red border */
            backdrop-filter: blur(10px);  /* Blur effect behind container */
            max-width: 600px;       /* Maximum width */
            width: 100%;            /* Full width up to max */
        }

        /* Header section styling */
        .header {
            text-align: center;     /* Center align header content */
            margin-bottom: 30px;    /* Space below header */
        }

        /* Main heading style */
        .header h1 {
            color: #ff6b6b;        /* Red color to match theme */
            font-size: 2.2rem;      /* Large font size */
            margin-bottom: 10px;    /* Space below heading */
            display: flex;          /* Flexbox for icon alignment */
            align-items: center;    /* Vertical center icon and text */
            justify-content: center; /* Horizontal center */
            gap: 15px;              /* Space between icon and text */
        }

        /* Icon styling in header */
        .header-icon {
            width: 50px;            /* Fixed width */
            height: 50px;           /* Fixed height */
            background: linear-gradient(135deg, #ff6b6b, #ff8e8e);  /* Red gradient */
            border-radius: 12px;    /* Rounded corners */
            display: flex;          /* Flexbox for centering icon */
            align-items: center;    /* Vertical center */
            justify-content: center; /* Horizontal center */
            color: white;           /* White icon color */
            font-size: 1.5rem;      /* Icon size */
        }

        /* Error message styling */
        .error {
            background: #ffebee;    /* Light red background */
            color: #c62828;         /* Dark red text */
            padding: 15px;          /* Inner spacing */
            border-radius: 10px;    /* Rounded corners */
            margin-bottom: 25px;    /* Space below error */
            text-align: center;     /* Center align text */
            border: 1px solid #ffcdd2;  /* Light red border */
        }

        /* Form group container */
        .form-group {
            margin-bottom: 25px;    /* Space between form fields */
        }

        /* Label styling */
        label {
            display: block;         /* Make label take full width */
            margin-bottom: 8px;     /* Space below label */
            color: #5d5d5d;         /* Dark gray color */
            font-weight: 500;       /* Medium font weight */
            font-size: 1rem;        /* Standard font size */
        }

        /* Input field styling */
        input, textarea, select {
            width: 100%;            /* Full width of container */
            padding: 15px 18px;     /* Inner spacing */
            border: 2px solid #e0e0e0;  /* Light gray border */
            border-radius: 12px;    /* Rounded corners */
            font-size: 1rem;        /* Standard font size */
            transition: all 0.3s ease;  /* Smooth hover/focus effects */
            background: #f8f9fa;    /* Light gray background */
        }

        /* Input focus state */
        input:focus, textarea:focus, select:focus {
            outline: none;          /* Remove default browser outline */
            border-color: #ff6b6b;  /* Red border on focus */
            background: white;      /* White background on focus */
            box-shadow: 0 0 0 3px rgba(255, 107, 107, 0.2);  /* Red glow effect */
        }

        /* Button group container */
        .btn-group {
            display: flex;          /* Flexbox for button layout */
            gap: 15px;              /* Space between buttons */
            margin-top: 30px;       /* Space above buttons */
        }

        /* Base button styling */
        .btn {
            flex: 1;                /* Buttons take equal width */
            padding: 15px 25px;     /* Button padding */
            border: none;           /* Remove default border */
            border-radius: 12px;    /* Rounded corners */
            cursor: pointer;        /* Pointer cursor on hover */
            font-size: 1rem;        /* Standard font size */
            font-weight: 500;       /* Medium font weight */
            transition: all 0.3s ease;  /* Smooth hover effects */
            text-align: center;     /* Center align text */
            text-decoration: none;  /* Remove underline from links */
        }

        /* Primary button (Update) */
        .btn-primary {
            background: linear-gradient(135deg, #ff6b6b, #ff8e8e);  /* Red gradient */
            color: white;           /* White text */
            box-shadow: 0 4px 15px rgba(255, 107, 107, 0.3);  /* Shadow */
        }

        /* Primary button hover effect */
        .btn-primary:hover {
            transform: translateY(-2px);  /* Lift button slightly */
            box-shadow: 0 8px 25px rgba(255, 107, 107, 0.4);  /* Enhanced shadow */
        }

        /* Secondary button (Cancel) */
        .btn-secondary {
            background: linear-gradient(135deg, #6c757d, #5a6268);  /* Gray gradient */
            color: white;           /* White text */
            box-shadow: 0 4px 15px rgba(108, 117, 125, 0.3);  /* Shadow */
        }

        /* Secondary button hover effect */
        .btn-secondary:hover {
            transform: translateY(-2px);  /* Lift button slightly */
            box-shadow: 0 8px 25px rgba(108, 117, 125, 0.4);  /* Enhanced shadow */
        }

        /* Form note text */
        .form-note {
            text-align: center;     /* Center align text */
            color: #666;            /* Medium gray color */
            font-style: italic;     /* Italic style */
            margin-top: 20px;       /* Space above note */
            font-size: 0.9rem;      /* Slightly smaller text */
        }

        /* Mobile responsive styles */
        @media (max-width: 768px) {
            .container {
                padding: 30px 20px;  /* Reduce padding on small screens */
            }
            
            .btn-group {
                flex-direction: column;  /* Stack buttons vertically */
            }
            
            .header h1 {
                font-size: 1.8rem;  /* Smaller heading on mobile */
            }
        }
    </style>
</head>
<body>
    <!-- Main content container -->
    <div class="container">
        <!-- Page header section -->
        <div class="header">
            <h1>
                <!-- Edit icon -->
                <div class="header-icon">✏️</div>
                <!-- Page title -->
                Edit Expense
            </h1>
            <!-- Subtitle -->
            <p style="color: #666; margin-top: 10px;">Update your expense record below</p>
        </div>
        
        <!-- Display error message if exists -->
        <?php if($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Edit expense form -->
        <form method="POST">
            <!-- Amount input field -->
            <div class="form-group">
                <label>Amount ($)</label>
                <!-- Number input for amount with validation -->
                <input type="number" name="amount" step="0.01" min="0.01" value="<?php echo $expense['Amount']; ?>" required>
            </div>
            
            <!-- Vendor input field -->
            <div class="form-group">
                <label>Vendor</label>
                <!-- Text input for vendor name -->
                <input type="text" name="vendor" value="<?php echo htmlspecialchars($expense['Vendor']); ?>" required>
            </div>
            
            <!-- Date input field -->
            <div class="form-group">
                <label>Date Spent</label>
                <!-- Date picker for expense date -->
                <input type="date" name="date_spent" value="<?php echo $expense['DateSpent']; ?>" required>
            </div>
            
            <!-- Description input field -->
            <div class="form-group">
                <label>Description</label>
                <!-- Textarea for optional expense description -->
                <textarea name="description" rows="4" placeholder="What was this expense for?"><?php echo htmlspecialchars($expense['Description']); ?></textarea>
            </div>
            
            <!-- Form action buttons -->
            <div class="btn-group">
                <!-- Submit button to update expense -->
                <button type="submit" name="update_expense" class="btn btn-primary">Update Expense</button>
                <!-- Cancel button to go back to expenses list -->
                <a href="expenses.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
        
        <!-- Help text for user -->
        <div class="form-note">
            Make your changes and click "Update Expense" to save
        </div>
    </div>
</body>
</html>