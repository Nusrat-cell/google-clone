<?php
// Start session to access user login information
session_start();

// Check if user is logged in, redirect to login if not
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Database connection settings
$host = 'localhost';                // Database server address
$dbname = 'financialtracker';      // Name of the database
$username = 'root';                // Database username
$password = '';                    // Database password

try {
    // Create PDO database connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set PDO to throw exceptions on errors
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    // Stop script and show error if connection fails
    die("❌ Connection failed: " . $e->getMessage());
}

// Initialize income data variable
$income = null;
// Check if income ID is provided in URL
if(isset($_GET['id'])) {
    // Prepare SQL to select specific income record
    $stmt = $pdo->prepare("SELECT * FROM incomes WHERE IncomeID = ?");
    // Execute query with the ID parameter
    $stmt->execute([$_GET['id']]);
    // Fetch the income record
    $income = $stmt->fetch();
}

// If income not found, show error and stop
if(!$income) {
    die("❌ Income not found!");
}

// Initialize error message variable
$error = '';
// Check if update form was submitted
if(isset($_POST['update_income'])) {
    // Get form data
    $amount = $_POST['amount'];             // Income amount
    $source = trim($_POST['source']);       // Income source (trim whitespace)
    $date = $_POST['date_received'];        // Date received
    $description = trim($_POST['description']); // Description (trim whitespace)
    
    // Validate required fields are not empty
    if(empty($amount) || empty($source) || empty($date)) {
        $error = "❌ Please fill all required fields!";
    } 
    // Validate amount is positive number
    elseif($amount <= 0) {
        $error = "❌ Amount must be greater than 0!";
    } 
    // Validate source has minimum length
    elseif(strlen($source) < 2) {
        $error = "❌ Source must be at least 2 characters!";
    } 
    // Validate date is not in future
    elseif($date > date('Y-m-d')) {
        $error = "❌ Date cannot be in the future!";
    } else {
        // If validation passes, update the income
        try {
            // Include IncomeService class for business logic
            require_once 'classes/IncomeService.class.php';
            // Create IncomeService instance
            $incomeService = new IncomeService($pdo);
            
            // Call update method from service class
            $incomeService->updateIncome($_GET['id'], $amount, $source, $date, $description);
            
            // Redirect to incomes page with success message
            header("Location: incomes.php?message=updated");
            exit();
        } catch (Exception $e) {
            // Catch and display any errors from service class
            $error = "❌ Error: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">                                  <!-- Character encoding -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  <!-- Responsive viewport -->
    <title>Edit Income - Financial Tracker</title>          <!-- Page title -->
    <style>
        /* Reset default browser styles */
        * {
            margin: 0;                                      /* Remove default margin */
            padding: 0;                                     /* Remove default padding */
            box-sizing: border-box;                         /* Include padding in width calculation */
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; /* Set font family */
        }

        /* Main page background with purple gradient */
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); /* Purple gradient */
            min-height: 100vh;                              /* Full viewport height */
            display: flex;                                  /* Flexbox for centering */
            align-items: center;                            /* Vertical center */
            justify-content: center;                        /* Horizontal center */
            padding: 20px;                                  /* Page padding */
        }

        /* Main content container */
        .container {
            background: rgba(255, 255, 255, 0.95);         /* Semi-transparent white */
            padding: 40px;                                  /* Inner spacing */
            border-radius: 20px;                            /* Rounded corners */
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);    /* Shadow for depth */
            border: 2px solid rgba(135, 195, 143, 0.3);    /* Green border */
            backdrop-filter: blur(10px);                    /* Background blur effect */
            max-width: 600px;                               /* Maximum width */
            width: 100%;                                    /* Full width up to max */
        }

        /* Header section styling */
        .header {
            text-align: center;                             /* Center align content */
            margin-bottom: 30px;                            /* Space below header */
        }

        /* Main heading style */
        .header h1 {
            color: #87c38f;                                /* Green color theme */
            font-size: 2.2rem;                              /* Large font size */
            margin-bottom: 10px;                            /* Space below heading */
            display: flex;                                  /* Flexbox for icon alignment */
            align-items: center;                            /* Vertical center */
            justify-content: center;                        /* Horizontal center */
            gap: 15px;                                      /* Space between icon and text */
        }

        /* Header icon styling */
        .header-icon {
            width: 50px;                                    /* Fixed width */
            height: 50px;                                   /* Fixed height */
            background: linear-gradient(135deg, #87c38f, #6aab73); /* Green gradient */
            border-radius: 12px;                            /* Rounded corners */
            display: flex;                                  /* Flexbox for centering */
            align-items: center;                            /* Vertical center */
            justify-content: center;                        /* Horizontal center */
            color: white;                                   /* White icon color */
            font-size: 1.5rem;                              /* Icon size */
        }

        /* Error message styling */
        .error {
            background: #ffebee;                            /* Light red background */
            color: #c62828;                                 /* Dark red text */
            padding: 15px;                                  /* Inner spacing */
            border-radius: 10px;                            /* Rounded corners */
            margin-bottom: 25px;                            /* Space below error */
            text-align: center;                             /* Center align text */
            border: 1px solid #ffcdd2;                      /* Light red border */
        }

        /* Form field group container */
        .form-group {
            margin-bottom: 25px;                            /* Space between form fields */
        }

        /* Label styling */
        label {
            display: block;                                 /* Block level element */
            margin-bottom: 8px;                             /* Space below label */
            color: #5d5d5d;                                 /* Dark gray color */
            font-weight: 500;                               /* Medium font weight */
            font-size: 1rem;                                /* Standard font size */
        }

        /* Input field styling */
        input, textarea, select {
            width: 100%;                                    /* Full width */
            padding: 15px 18px;                             /* Inner spacing */
            border: 2px solid #e0e0e0;                      /* Light gray border */
            border-radius: 12px;                            /* Rounded corners */
            font-size: 1rem;                                /* Standard font size */
            transition: all 0.3s ease;                      /* Smooth transitions */
            background: #f8f9fa;                            /* Light gray background */
        }

        /* Input focus state */
        input:focus, textarea:focus, select:focus {
            outline: none;                                  /* Remove default outline */
            border-color: #87c38f;                          /* Green border on focus */
            background: white;                              /* White background */
            box-shadow: 0 0 0 3px rgba(135, 195, 143, 0.2); /* Green glow effect */
        }

        /* Button group container */
        .btn-group {
            display: flex;                                  /* Flexbox layout */
            gap: 15px;                                      /* Space between buttons */
            margin-top: 30px;                               /* Space above buttons */
        }

        /* Base button styling */
        .btn {
            flex: 1;                                        /* Equal width buttons */
            padding: 15px 25px;                             /* Button padding */
            border: none;                                   /* Remove border */
            border-radius: 12px;                            /* Rounded corners */
            cursor: pointer;                                /* Pointer cursor */
            font-size: 1rem;                                /* Standard font size */
            font-weight: 500;                               /* Medium font weight */
            transition: all 0.3s ease;                      /* Smooth hover effects */
            text-align: center;                             /* Center align text */
            text-decoration: none;                          /* Remove underline from links */
        }

        /* Primary button (Update Income) */
        .btn-primary {
            background: linear-gradient(135deg, #87c38f, #6aab73); /* Green gradient */
            color: white;                                   /* White text */
            box-shadow: 0 4px 15px rgba(135, 195, 143, 0.3); /* Shadow */
        }

        /* Primary button hover effect */
        .btn-primary:hover {
            transform: translateY(-2px);                    /* Lift button up */
            box-shadow: 0 8px 25px rgba(135, 195, 143, 0.4); /* Enhanced shadow */
        }

        /* Secondary button (Cancel) */
        .btn-secondary {
            background: linear-gradient(135deg, #6c757d, #5a6268); /* Gray gradient */
            color: white;                                   /* White text */
            box-shadow: 0 4px 15px rgba(108, 117, 125, 0.3); /* Shadow */
        }

        /* Secondary button hover effect */
        .btn-secondary:hover {
            transform: translateY(-2px);                    /* Lift button up */
            box-shadow: 0 8px 25px rgba(108, 117, 125, 0.4); /* Enhanced shadow */
        }

        /* Form note text */
        .form-note {
            text-align: center;                             /* Center align */
            color: #666;                                    /* Medium gray */
            font-style: italic;                             /* Italic style */
            margin-top: 20px;                               /* Space above */
            font-size: 0.9rem;                              /* Smaller text */
        }

        /* Mobile responsive styles */
        @media (max-width: 768px) {
            .container {
                padding: 30px 20px;                         /* Reduced padding on mobile */
            }
            
            .btn-group {
                flex-direction: column;                     /* Stack buttons vertically */
            }
            
            .header h1 {
                font-size: 1.8rem;                          /* Smaller heading on mobile */
            }
        }
    </style>
</head>
<body>
    <!-- Main content container -->
    <div class="container">
        <!-- Page header section -->
        <div class="header">
            <h1>
                <!-- Edit icon -->
                <div class="header-icon">✏️</div>
                <!-- Page title -->
                Edit Income
            </h1>
            <!-- Page subtitle -->
            <p style="color: #666; margin-top: 10px;">Update your income record below</p>
        </div>
        
        <!-- Display error message if exists -->
        <?php if($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Edit income form -->
        <form method="POST">
            <!-- Amount input field -->
            <div class="form-group">
                <label>Amount ($)</label>
                <!-- Number input for amount with validation -->
                <input type="number" name="amount" step="0.01" min="0.01" value="<?php echo $income['Amount']; ?>" required>
            </div>
            
            <!-- Source input field -->
            <div class="form-group">
                <label>Source</label>
                <!-- Text input for income source -->
                <input type="text" name="source" value="<?php echo htmlspecialchars($income['Source']); ?>" required>
            </div>
            
            <!-- Date input field -->
            <div class="form-group">
                <label>Date Received</label>
                <!-- Date picker for income date -->
                <input type="date" name="date_received" value="<?php echo $income['DateReceived']; ?>" required>
            </div>
            
            <!-- Description input field -->
            <div class="form-group">
                <label>Description</label>
                <!-- Textarea for optional description -->
                <textarea name="description" rows="4" placeholder="Additional notes about this income..."><?php echo htmlspecialchars($income['Description']); ?></textarea>
            </div>
            
            <!-- Form action buttons -->
            <div class="btn-group">
                <!-- Submit button to update income -->
                <button type="submit" name="update_income" class="btn btn-primary">Update Income</button>
                <!-- Cancel button to return to incomes list -->
                <a href="incomes.php" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
        
        <!-- Help text for user -->
        <div class="form-note">
            Make your changes and click "Update Income" to save
        </div>
    </div>
</body>
</html>