<?php
// File: dashboard-finance2/navigation.php
// Purpose: Navigation menu for financial dashboard
// Provides links to different sections of the financial tracking system
?>

<!-- Navigation menu container with dark background -->
<nav style="background: #333; padding: 15px; color: white;">
    <!-- Dashboard link - main overview page -->
    <a href="index.php" style="color: white; margin-right: 15px;">Dashboard</a>
    
    <!-- Add Transaction link - for creating new financial transactions -->
    <a href="add_transaction.php" style="color: white; margin-right: 15px;">Add Transaction</a>
    
    <!-- Manage Budgets link - for setting up and managing budget limits -->
    <a href="manage_budgets.php" style="color: white; margin-right: 15px;">Manage Budgets</a>
    
    <!-- ADD THESE TWO LINKS -->
    <!-- My Income link - navigates to income management page in FinancialTrackerAPI folder -->
    <a href="../FinancialTrackerAPI/incomes.php" style="color: white; margin-right: 15px;">My Income</a>
    
    <!-- My Expenses link - navigates to expense management page in FinancialTrackerAPI folder -->
    <a href="../FinancialTrackerAPI/expenses.php" style="color: white; margin-right: 15px;">My Expenses</a>
</nav>