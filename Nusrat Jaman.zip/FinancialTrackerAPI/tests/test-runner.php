[file name]: test-runner.php
[file content begin]
<?php
// =============================================================================
// FILE: test-runner.php
// PURPOSE: Simple test runner for Financial Tracker application
// DESCRIPTION: 
// - Runs basic system tests without requiring terminal/command line
// - Checks PHP environment, file existence, database connectivity
// - Generates test data for validation testing
// - Provides visual pass/fail indicators in browser
// USAGE: Access via browser at http://localhost/path/to/test-runner.php
// =============================================================================

// =============================================================================
// SECTION: Test Output Setup
// PURPOSE: Initialize HTML output for test results
// =============================================================================

// Output HTML heading for test results page
echo "<h2>Financial Tracker Tests</h2>";

// Start preformatted text block for structured test output
echo "<pre>";

// =============================================================================
// TEST 1: PHP Environment Validation
// PURPOSE: Verify basic PHP functionality and environment
// =============================================================================

// Output test section header
echo "=== TEST 1: PHP BASICS ===\n";

// Test 1.1: Check PHP version
echo "✓ PHP Version: " . phpversion() . "\n";

// Test 1.2: Verify basic arithmetic functionality
echo "✓ 2 + 2 = " . (2 + 2) . "\n";

// Test 1.3: Verify date/time functionality
echo "✓ Current Time: " . date('Y-m-d H:i:s') . "\n";

// =============================================================================
// TEST 2: File System Validation
// PURPOSE: Check if required application files exist
// =============================================================================

// Output test section header
echo "\n=== TEST 2: CHECKING FILES ===\n";

// Define array of critical application files to check
$files = [
    'classes/IncomeService.class.php',  // Income service class file
    'classes/BudgetService.class.php',   // Budget service class file
    'classes/SecurityService.class.php', // Security service class file
    'incomes.php',                       // Main incomes page
    'expenses.php'                       // Main expenses page
];

// =============================================================================
// LOOP: Check each required file
// PURPOSE: Verify all critical application files exist
// =============================================================================

// Iterate through each file in the array
foreach ($files as $file) {
    // Check if file exists in filesystem
    if (file_exists($file)) {
        // File exists - output success indicator
        echo "✓ $file exists\n";
    } else {
        // File missing - output failure indicator
        echo "✗ $file NOT FOUND\n";
    }
}

// =============================================================================
// TEST 3: Database Connectivity
// PURPOSE: Verify database connection and structure
// =============================================================================

// Output test section header
echo "\n=== TEST 3: DATABASE ===\n";

// Try-catch block for database connection testing
try {
    // =========================================================================
    // DATABASE CONNECTION: Create PDO connection
    // PURPOSE: Connect to MySQL database for testing
    // PARAMETERS: host=localhost, dbname=financialtracker, user=root, password=''
    // =========================================================================
    $pdo = new PDO('mysql:host=localhost;dbname=financialtracker', 'root', '');
    
    // Database connection successful - output success
    echo "✓ Database connection successful\n";
    
    // =========================================================================
    // DATABASE STRUCTURE: Check if incomes table exists
    // PURPOSE: Verify critical database table exists
    // METHOD: Execute SHOW TABLES query with LIKE clause
    // =========================================================================
    
    // Query to check if incomes table exists
    $tables = $pdo->query("SHOW TABLES LIKE 'incomes'")->fetch();
    
    // Check if query returned a result (table exists)
    if ($tables) {
        // Table exists - output success
        echo "✓ 'incomes' table exists\n";
    } else {
        // Table missing - output failure
        echo "✗ 'incomes' table NOT found\n";
    }
    
} catch (Exception $e) {
    // Database connection failed - output error details
    echo "✗ Database error: " . $e->getMessage() . "\n";
}

// =============================================================================
// TEST 4: Test Data Generation
// PURPOSE: Demonstrate test data creation for validation
// =============================================================================

// Output test section header
echo "\n=== TEST 4: CREATE TEST DATA ===\n";

// =============================================================================
// TEST DATA: Define sample income records
// PURPOSE: Create realistic test data for validation testing
// STRUCTURE: Array of associative arrays with amount, source, date, description
// =============================================================================
$test_data = [
    ['amount' => 1000, 'source' => 'Test Salary', 'date' => date('Y-m-d'), 'desc' => 'Test income'],
    ['amount' => 500, 'source' => 'Test Bonus', 'date' => date('Y-m-d'), 'desc' => 'Test bonus'],
];

// Output confirmation of test data creation
echo "Created 2 test income records\n";

// =============================================================================
// TEST 5: Validation Rule Testing
// PURPOSE: Test various amount validation scenarios
// =============================================================================

// Output test section header
echo "\n=== TEST 5: VALIDATION TESTS ===\n";

// =============================================================================
// TEST CASES: Define various amount validation test cases
// PURPOSE: Test positive, zero, negative, and boundary amounts
// =============================================================================
$tests = [
    'Positive Amount' => 100.00,   // Valid: Positive amount
    'Zero Amount' => 0.00,         // Invalid: Zero amount
    'Negative Amount' => -50.00,   // Invalid: Negative amount
    'Large Amount' => 999999.99    // Valid: Large positive amount
];

// =============================================================================
// LOOP: Execute each validation test
// PURPOSE: Check each amount against validation rules
// =============================================================================

// Iterate through each test case
foreach ($tests as $name => $amount) {
    // Check if amount is positive (validation rule)
    if ($amount > 0) {
        // Amount is valid (positive) - output success
        echo "✓ $name ($amount) is valid\n";
    } else {
        // Amount is invalid (zero or negative) - output failure
        echo "✗ $name ($amount) is INVALID\n";
    }
}

// =============================================================================
// SECTION: Test Results Summary
// PURPOSE: Provide final summary and instructions
// =============================================================================

// Output test completion message
echo "\n=== ALL TESTS COMPLETE ===\n";

// Output separator line for visual clarity
echo "=======================\n";

// Provide interpretation instructions for test results
echo "Tests passed: Look for ✓ marks\n";

// Provide interpretation instructions for failed tests
echo "Tests failed: Look for ✗ marks\n";

// Close preformatted text block
echo "</pre>";
?>
[file content end]