<?php
// =============================================================================
// FILE: test-suite.php
// PURPOSE: Comprehensive test suite with actual boundary testing
// UPDATED: Now includes exact boundary tests from portfolio claims
// =============================================================================

echo "<h1>Financial Tracker - Complete Test Suite (Matches Portfolio)</h1>";
echo "<pre style='background:#f5f5f5;padding:20px;border-radius:10px;'>";

$total_tests = 0;
$passed_tests = 0;
$failed_tests = 0;

// Test function
function test($name, $condition, $message) {
    global $total_tests, $passed_tests, $failed_tests;
    $total_tests++;
    
    if ($condition) {
        echo "✅ $name: PASS - $message\n";
        $passed_tests++;
    } else {
        echo "❌ $name: FAIL - $message\n";
        $failed_tests++;
    }
    return $condition;
}

// =============================================================================
// EXACT BOUNDARY TESTS FROM PORTFOLIO
// =============================================================================

echo "=== STRING BOUNDARY TESTS (Matches Portfolio Table) ===\n";

// Extreme Min: Empty string
test("String - Extreme Min (\"\")", 
    !validateString("", 2, 100), 
    "Empty string should be rejected - 'Source field is required'");

// Min-1: 1 character
test("String - Min-1 (\"A\")", 
    !validateString("A", 2, 100), 
    "1 character should be rejected");

// Min Boundary: 2 characters
test("String - Min Boundary (\"Sa\")", 
    validateString("Sa", 2, 100), 
    "2 characters should be accepted (Min boundary)");

// Min+1: 3 characters
test("String - Min+1 (\"Sal\")", 
    validateString("Sal", 2, 100), 
    "3 characters should be accepted");

// Max-1: 99 characters
$maxMinusOne = str_repeat("A", 99);
test("String - Max-1 (99 chars)", 
    validateString($maxMinusOne, 2, 100), 
    "99 characters should be accepted");

// Max Boundary: 100 characters
$maxBoundary = str_repeat("A", 100);
test("String - Max Boundary (100 chars)", 
    validateString($maxBoundary, 2, 100), 
    "100 characters should be accepted (Max boundary)");

// Max+1: 101 characters
$maxPlusOne = str_repeat("A", 101);
test("String - Max+1 (101 chars)", 
    !validateString($maxPlusOne, 2, 100), 
    "101 characters should be rejected - 'Source cannot exceed 100 characters'");

// Mid: 50 characters
$midValue = str_repeat("A", 50);
test("String - Mid (50 chars)", 
    validateString($midValue, 2, 100), 
    "50 characters should be accepted");

// Extreme Max: 500 characters
$extremeMax = str_repeat("A", 500);
test("String - Extreme Max (500 chars)", 
    !validateString($extremeMax, 2, 100), 
    "500 characters should be rejected");

// Special characters
test("String - Special Chars (\"Salary & Bonus!\")", 
    validateString("Salary & Bonus!", 2, 100), 
    "Special characters should be accepted");

// Invalid data type (number)
test("String - Invalid Type (12345)", 
    !validateString(12345, 2, 100), 
    "Numbers should be rejected - 'Source must be text'");

echo "\n=== NUMERIC BOUNDARY TESTS (Matches Portfolio Table) ===\n";

// Extreme Min: 0.00
test("Numeric - Extreme Min (0.00)", 
    !validateNumber(0.00, 0.01, 999999.99), 
    "0.00 should be rejected - 'Amount must be greater than 0.00'");

// Min-1: -0.01
test("Numeric - Min-1 (-0.01)", 
    !validateNumber(-0.01, 0.01, 999999.99), 
    "-0.01 should be rejected - 'Amount cannot be negative'");

// Min Boundary: 0.01
test("Numeric - Min Boundary (0.01)", 
    validateNumber(0.01, 0.01, 999999.99), 
    "0.01 should be accepted (Min boundary)");

// Min+1: 0.02
test("Numeric - Min+1 (0.02)", 
    validateNumber(0.02, 0.01, 999999.99), 
    "0.02 should be accepted");

// Max-1: 999,999.98
test("Numeric - Max-1 (999,999.98)", 
    validateNumber(999999.98, 0.01, 999999.99), 
    "999,999.98 should be accepted");

// Max Boundary: 999,999.99
test("Numeric - Max Boundary (999,999.99)", 
    validateNumber(999999.99, 0.01, 999999.99), 
    "999,999.99 should be accepted (Max boundary)");

// Max+1: 1,000,000.00
test("Numeric - Max+1 (1,000,000.00)", 
    !validateNumber(1000000.00, 0.01, 999999.99), 
    "1,000,000.00 should be rejected - 'Amount exceeds maximum'");

// Mid: 500,000.00
test("Numeric - Mid (500,000.00)", 
    validateNumber(500000.00, 0.01, 999999.99), 
    "500,000.00 should be accepted");

// Extreme Max: 99,999,999.99
test("Numeric - Extreme Max (99,999,999.99)", 
    !validateNumber(99999999.99, 0.01, 999999.99), 
    "99,999,999.99 should be rejected");

// Invalid data type (text)
test("Numeric - Invalid Type (\"one hundred\")", 
    !validateNumber("one hundred", 0.01, 999999.99), 
    "Text should be rejected - 'Amount must be a number'");

// Decimal amount
test("Numeric - Decimal (100.50)", 
    validateNumber(100.50, 0.01, 999999.99), 
    "100.50 should be accepted");

echo "\n=== DATE BOUNDARY TESTS (Matches Portfolio Table) ===\n";

// Extreme Min: 1900-01-01
test("Date - Extreme Min (1900-01-01)", 
    !validateDate("1900-01-01", "2024-01-01", date("Y-m-d")), 
    "1900-01-01 should be rejected - 'Date must be on or after January 1, 2024'");

// Min-1: 2023-12-31
test("Date - Min-1 (2023-12-31)", 
    validateDate("2023-12-31", "2024-01-01", date("Y-m-d")), 
    "2023-12-31 should be accepted");

// Min Boundary: 2024-01-01
test("Date - Min Boundary (2024-01-01)", 
    validateDate("2024-01-01", "2024-01-01", date("Y-m-d")), 
    "2024-01-01 should be accepted (Min boundary)");

// Min+1: 2024-01-02
test("Date - Min+1 (2024-01-02)", 
    validateDate("2024-01-02", "2024-01-01", date("Y-m-d")), 
    "2024-01-02 should be accepted");

// Max-1: 2025-12-30
test("Date - Max-1 (2025-12-30)", 
    validateDate("2025-12-30", "2024-01-01", "2025-12-31"), 
    "2025-12-30 should be accepted");

// Max Boundary: 2025-12-31
test("Date - Max Boundary (2025-12-31)", 
    validateDate("2025-12-31", "2024-01-01", "2025-12-31"), 
    "2025-12-31 should be accepted (Max boundary)");

// Max+1: 2026-01-01
test("Date - Max+1 (2026-01-01)", 
    !validateDate("2026-01-01", "2024-01-01", "2025-12-31"), 
    "2026-01-01 should be rejected - 'Date cannot be beyond December 31, 2025'");

// Mid: 2024-07-01
test("Date - Mid (2024-07-01)", 
    validateDate("2024-07-01", "2024-01-01", "2025-12-31"), 
    "2024-07-01 should be accepted");

// Extreme Max: 2030-01-01
test("Date - Extreme Max (2030-01-01)", 
    !validateDate("2030-01-01", "2024-01-01", date("Y-m-d")), 
    "2030-01-01 should be rejected");

// Invalid format
test("Date - Invalid Format (\"not-a-date\")", 
    !validateDate("not-a-date", "2024-01-01", "2025-12-31"), 
    "Invalid format should be rejected - 'Invalid date format. Please use YYYY-MM-DD'");

// Non-existent date
test("Date - Non-existent (2024-02-30)", 
    !validateDate("2024-02-30", "2024-01-01", "2025-12-31"), 
    "2024-02-30 should be rejected - 'Invalid calendar date'");

echo "\n=== BOOLEAN TESTS (Matches Portfolio Table) ===\n";

// NULL (Extreme Min)
test("Boolean - NULL", 
    validateBooleanForDB(null), 
    "NULL should be accepted and default to FALSE");

// FALSE (Min Boundary)
test("Boolean - FALSE", 
    validateBooleanForDB(false), 
    "FALSE should be accepted");

// TRUE (Max Boundary)
test("Boolean - TRUE", 
    validateBooleanForDB(true), 
    "TRUE should be accepted");

// TRUE again (Mid test - booleans only have 2 values)
test("Boolean - TRUE (Mid)", 
    validateBooleanForDB(true), 
    "TRUE should work consistently");

// Integer 1 (as TRUE)
test("Boolean - Integer 1", 
    validateBooleanForDB(1), 
    "Integer 1 should be accepted as TRUE");

// Integer 0 (as FALSE)
test("Boolean - Integer 0", 
    validateBooleanForDB(0), 
    "Integer 0 should be accepted as FALSE");

// Invalid type
test("Boolean - Invalid (\"yes\")", 
    !validateBooleanForDB("yes"), 
    "Text 'yes' should be rejected - 'Must be TRUE or FALSE (or 1/0)'");

// =============================================================================
// TEST SUMMARY
// =============================================================================

echo "\n" . str_repeat("=", 60) . "\n";
echo "TEST SUMMARY - MATCHES PORTFOLIO BOUNDARY TESTING TABLES\n";
echo str_repeat("=", 60) . "\n";

echo "Total Tests Executed: $total_tests\n";
echo "Passed: $passed_tests\n";
echo "Failed: $failed_tests\n";
echo "Success Rate: " . round(($passed_tests/$total_tests)*100, 2) . "%\n\n";

echo "DATA TYPES TESTED (All 4 from Portfolio):\n";
echo "✅ String: All boundary conditions tested (1-100 chars)\n";
echo "✅ Numeric: All boundary conditions tested (0.01-999,999.99)\n";
echo "✅ Date: All boundary conditions tested (2024-01-01 to 2025-12-31)\n";
echo "✅ Boolean: TRUE/FALSE/NULL all tested\n\n";

echo "BOUNDARY TESTING COMPLETE:\n";
echo "- Extreme Min, Min-1, Min, Min+1 ✓\n";
echo "- Max-1, Max, Max+1 ✓\n";
echo "- Mid values ✓\n";
echo "- Invalid data types ✓\n";
echo "- Special cases ✓\n\n";

if ($failed_tests == 0) {
    echo "🎉 ALL TESTS PASSED - Exactly matches portfolio boundary testing claims!\n";
} else {
    echo "⚠ $failed_tests tests failed - Review above\n";
}

echo "</pre>";

// =============================================================================
// VALIDATION FUNCTIONS
// =============================================================================

function validateString($value, $min, $max) {
    if (!is_string($value)) return false;
    $length = strlen(trim($value));
    return $length >= $min && $length <= $max;
}

function validateNumber($value, $min, $max) {
    if (!is_numeric($value)) return false;
    return $value >= $min && $value <= $max;
}

function validateDate($date, $min_date, $max_date) {
    // Check if valid date
    $timestamp = strtotime($date);
    if ($timestamp === false) return false;
    
    // Check if date exists in calendar
    $parsed_date = date("Y-m-d", $timestamp);
    if ($parsed_date !== $date) return false;
    
    return $date >= $min_date && $date <= $max_date;
}

function validateBooleanForDB($value) {
    // Accept NULL, TRUE, FALSE, 1, 0
    return $value === null || 
           $value === true || $value === false || 
           $value === 1 || $value === 0;
}
?>