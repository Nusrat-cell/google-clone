<?php
/**
 * BudgetService - Handles all budget-related business logic
 * Responsible for budget creation, retrieval, and period calculations
 */
class BudgetService {
    private $pdo; // Database connection object
    
    /**
     * Constructor - Dependency injection for database connection
     * @param PDO $pdo - Database connection instance
     */
    public function __construct($pdo) {
        $this->pdo = $pdo; // Store database connection for all methods to use
    }
    
    /**
     * Creates a new budget with automatic period calculation
     * Handles both one-time and recurring budgets
     * 
     * @param int $user_id - The ID of the user creating the budget
     * @param string $category - Budget category (e.g., 'Food', 'Entertainment')
     * @param float $amount - Budget amount (must be positive)
     * @param string $period - Budget period: 'weekly', 'monthly', 'yearly'
     * @param bool $repeat_budget - Whether this budget should repeat automatically
     * @param string $repeat_interval - How often to repeat ('monthly', etc.)
     * @return bool - Success status of the database operation
     * @throws Exception - If validation fails or invalid parameters provided
     */
    public function addBudget($user_id, $category, $amount, $period, $repeat_budget = false, $repeat_interval = 'monthly') {
        // Input validation - crucial for data integrity and security
        // This prevents invalid data from being saved to the database
        if ($amount <= 0) {
            throw new Exception("Budget amount must be greater than 0"); // Business rule: budgets must have positive amounts
        }
        if (strlen($category) < 2) {
            throw new Exception("Category must be at least 2 characters"); // Business rule: category names must be meaningful
        }
        
        // Calculate period dates - business logic for budget timeframe
        $start_date = date('Y-m-d'); // Budget starts today - using current date
        
        // Determine end date based on selected period
        // Using switch for clarity when dealing with multiple conditions
        // This is CORE BUSINESS LOGIC: defining what "weekly", "monthly", "yearly" actually means
        switch($period) {
            case 'weekly': 
                $end_date = date('Y-m-d', strtotime('+1 week')); // Add 7 days to start date
                break;
            case 'monthly': 
                $end_date = date('Y-m-d', strtotime('+1 month')); // Add 1 month to start date
                break;
            case 'yearly': 
                $end_date = date('Y-m-d', strtotime('+1 year')); // Add 1 year to start date
                break;
            default: 
                // Fallback to monthly if invalid period provided
                // This provides a sensible default instead of crashing
                $end_date = date('Y-m-d', strtotime('+1 month'));
        }
        
        // Prepared statement to prevent SQL injection
        // This is a SECURITY CRITICAL practice - separates SQL code from data
        $sql = "INSERT INTO budgets (user_id, category, amount, period, start_date, end_date, repeat_budget, repeat_interval) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $this->pdo->prepare($sql); // Prepare the SQL statement
        
        // Execute with parameters in correct order
        // The parameters are bound to the ? placeholders, preventing SQL injection
        return $stmt->execute([
            $user_id, 
            $category, 
            $amount, 
            $period, 
            $start_date, 
            $end_date, 
            $repeat_budget, // Whether this budget will automatically renew
            $repeat_interval // How often it repeats if repeat_budget is true
        ]);
    }
    
    /**
     * Retrieves all budgets for a specific user
     * Returns budgets in reverse chronological order (newest first)
     * 
     * @param int $user_id - The ID of the user whose budgets to retrieve
     * @return array - Array of budget records from database
     */
    public function getUserBudgets($user_id) {
        // SELECT * is acceptable here since we want all budget fields
        // Ordered by creation date descending to show newest budgets first
        // This is for USER EXPERIENCE - users typically want to see their most recent budgets first
        $sql = "SELECT * FROM budgets WHERE user_id = ? ORDER BY created_at DESC";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$user_id]); // Execute with user_id parameter
        
        // fetchAll returns all results as associative array
        // This converts the database result into a PHP array we can work with
        return $stmt->fetchAll();
    }
}
?>