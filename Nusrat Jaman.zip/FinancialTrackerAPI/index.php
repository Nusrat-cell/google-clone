<?php
// =============================================
// SIMPLIFIED DASHBOARD - FIXED VERSION
// =============================================

// Start PHP session to maintain user state across page requests
session_start();

// Simple database configuration (remove this once you create config/database.php)
$host = 'localhost';        // Database server hostname
$dbname = 'financialtracker'; // Name of the database
$username = 'root';         // Database username
$password = '';             // Database password

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Basic HTML document setup -->
    <meta charset="UTF-8">  <!-- Character encoding for proper text display -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">  <!-- Responsive design for mobile devices -->
    <title>Financial Dashboard</title>  <!-- Page title shown in browser tab -->
    <style>
        /* Global body styling */
        body {
            font-family: Arial, sans-serif;  /* Clean, readable font */
            background: #f4f4f4;  /* Light gray background for the page */
            margin: 0;  /* Remove default browser margins */
            padding: 20px;  /* Add spacing around page edges */
        }
        
        /* Main content container */
        .container {
            max-width: 900px;  /* Maximum width for large screens */
            margin: 0 auto;  /* Center container horizontally */
            background: white;  /* White background for content area */
            padding: 30px;  /* Internal spacing inside container */
            border-radius: 8px;  /* Rounded corners for modern look */
            box-shadow: 0 0 10px rgba(0,0,0,0.1);  /* Subtle shadow for depth */
        }
        
        /* Main heading styling */
        h1 {
            text-align: center;  /* Center align the heading */
            color: #333;  /* Dark gray color for good readability */
        }
        
        /* Navigation links container */
        .nav-links {
            display: flex;  /* Flexbox for horizontal layout */
            justify-content: center;  /* Center links horizontally */
            gap: 15px;  /* Space between navigation links */
            margin: 30px 0;  /* Vertical spacing above and below */
            flex-wrap: wrap;  /* Allow links to wrap on small screens */
        }
        
        /* Individual navigation link styling */
        .nav-links a {
            background: #007bff;  /* Blue background color */
            color: white;  /* White text color for contrast */
            padding: 12px 20px;  /* Internal spacing for clickable area */
            text-decoration: none;  /* Remove underline from links */
            border-radius: 6px;  /* Rounded corners for buttons */
            transition: background-color 0.3s;  /* Smooth color transition on hover */
        }
        
        /* Navigation link hover effect */
        .nav-links a:hover {
            background: #0056b3;  /* Darker blue on hover for feedback */
        }
        
        /* Welcome message styling */
        .welcome {
            text-align: center;  /* Center align welcome text */
            font-size: 1.2em;  /* Slightly larger font size */
            margin: 20px 0;  /* Vertical spacing around welcome message */
        }
    </style>
</head>
<body>
    <!-- Main content container -->
    <div class="container">
        <!-- Main page heading with money bag emoji -->
        <h1>💰 Financial Tracker Dashboard</h1>
        
        <!-- Welcome message section -->
        <div class="welcome">
            <p>Welcome to your Financial Tracker! Manage your income and expenses efficiently.</p>
        </div>

        <!-- Navigation links section -->
        <div class="nav-links">
            <!-- Income management link with money bag emoji -->
            <a href="incomes.php">💰 Income Management</a>
            <!-- Expense management link with money with wings emoji -->
            <a href="expenses.php">💸 Expense Management</a>
            <!-- Login link with lock emoji and green background -->
            <a href="login.php" style="background: #28a745;">🔐 Login</a>
        </div>

        <!-- Getting started help section -->
        <div style="text-align: center; margin-top: 40px; padding: 20px; background: #f8f9fa; border-radius: 8px;">
            <!-- Help section heading -->
            <h3>Getting Started</h3>
            <!-- Help section text -->
            <p>Start by managing your incomes or expenses using the links above.</p>
        </div>
    </div>
</body>
</html>