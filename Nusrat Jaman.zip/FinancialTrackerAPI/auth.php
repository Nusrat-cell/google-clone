<?php
// =============================================
// AUTHENTICATION SYSTEM  
// =============================================
// File: auth.php
// Purpose: Handles user session management and authentication

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection
//require_once __DIR__ . '/data/db-connect.php'; // File doesn't exist

/**
 * Checks if user is logged in
 * @return bool True if user is logged in, false otherwise
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Redirects to login page if user is not authenticated
 * Call this at top of each protected page
 */
function requireAuth() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit();
    }
}

// NOTE: We don't call requireAuth() here anymore
// Each protected page will call it individually
?>