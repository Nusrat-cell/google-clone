<?php
// Start a session to access user authentication data
session_start();

// Check if user is logged in by verifying session variable exists
// If user_id is not set in session, redirect to login page for security
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(); // Stop script execution immediately after redirect
}
// ... rest of your existing delete code
?>

<?php
// Database connection configuration
// These credentials are used to connect to MySQL database
$host = 'localhost';      // Database server location
$dbname = 'financialtracker'; // Name of your financial database
$username = 'root';       // Database username (default for XAMPP/WAMP)
$password = '';           // Database password (empty by default in XAMPP/WAMP)

try {
    // Create a new PDO (PHP Data Objects) database connection
    // PDO provides a secure way to interact with databases
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    
    // Set error handling mode to exceptions for better error reporting
    // This means database errors will throw exceptions that we can catch
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
} catch(PDOException $e) {
    // If connection fails, display error message and stop script execution
    // This prevents the script from running without a valid database connection
    die("❌ Connection failed: " . $e->getMessage());
}

// Delete expense logic - this runs when an expense ID is provided in the URL
// This is typically called from expenses.php when user clicks "delete" on an expense
if(isset($_GET['id'])) {
    // Prepare SQL statement to prevent SQL injection attacks
    // The ? is a placeholder that will be safely replaced with the actual ID
    $stmt = $pdo->prepare("DELETE FROM expenses WHERE ExpenseID = ?");
    
    // Execute the prepared statement with the expense ID from URL parameter
    // $_GET['id'] contains the ID of the expense to delete
    if($stmt->execute([$_GET['id']])) {
        // If delete operation is successful, redirect back to expenses page
        // The message parameter will show a success notification on expenses.php
        header("Location: expenses.php?message=deleted");
        exit(); // Always exit after header redirect to prevent further execution
    } else {
        // If the execute() method returns false, show error message
        die("❌ Error deleting expense!");
    }
} else {
    // If no ID parameter is provided in URL, redirect back to expenses page
    // This prevents the script from running without a valid expense ID
    header("Location: expenses.php");
    exit();
}
?>