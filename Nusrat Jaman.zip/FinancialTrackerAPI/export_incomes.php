<?php
// Start PHP session to maintain user authentication state
session_start();

// Check if user is logged in, if not set default user ID for development
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1;  // Set default user ID for testing purposes
}

// Database connection configuration
$host = 'localhost';        // Database server hostname
$dbname = 'financialtracker'; // Name of the database to connect to
$username = 'root';         // Database username (default for localhost)
$password = '';             // Database password (empty for local development)

try {
    // Create PDO database connection object
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Set PDO error mode to exceptions for better error handling
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    // Stop execution and display error message if database connection fails
    die("Database connection failed: " . $e->getMessage());
}

// Get search filters from URL parameters with null coalescing for safety
$search_query = $_GET['search_query'] ?? '';        // Text search query from URL
$filter_start_date = $_GET['start_date'] ?? '';     // Start date filter from URL
$filter_end_date = $_GET['end_date'] ?? '';         // End date filter from URL
$filter_min_amount = $_GET['min_amount'] ?? '';     // Minimum amount filter from URL
$filter_source = $_GET['source_search'] ?? '';      // Income source search filter from URL

// Build SQL query for filtering incomes (same as in incomes.php)
$sql = "SELECT * FROM incomes WHERE 1=1";  // Base query with 1=1 for easy AND condition appending
$params = [];  // Array to hold prepared statement parameters

// Add start date filter if provided
if(!empty($filter_start_date)) {
    $sql .= " AND DateReceived >= ?";  // Append date filter condition for start date
    $params[] = $filter_start_date;    // Add start date to parameters array
}

// Add end date filter if provided
if(!empty($filter_end_date)) {
    $sql .= " AND DateReceived <= ?";  // Append date filter condition for end date
    $params[] = $filter_end_date;      // Add end date to parameters array
}

// Add minimum amount filter if provided
if(!empty($filter_min_amount)) {
    $sql .= " AND Amount >= ?";        // Append amount filter condition
    $params[] = $filter_min_amount;    // Add minimum amount to parameters array
}

// Add source search filter if provided
if(!empty($filter_source)) {
    $sql .= " AND Source LIKE ?";      // Append source search with LIKE for partial matching
    $params[] = '%' . $filter_source . '%';  // Add source search term with wildcards
}

// Order results by most recent income dates first
$sql .= " ORDER BY DateReceived DESC";

// Prepare and execute the SQL query with filters
$stmt = $pdo->prepare($sql);  // Create prepared statement for security
$stmt->execute($params);      // Execute query with filter parameters
$incomes = $stmt->fetchAll(); // Fetch all matching income records as array

// Set HTTP headers for CSV file download
header('Content-Type: text/csv; charset=utf-8');  // Set content type as CSV with UTF-8 encoding
header('Content-Disposition: attachment; filename=incomes_export_' . date('Y-m-d_H-i-s') . '.csv');  // Force download with timestamped filename

// Create output stream for writing CSV data
$output = fopen('php://output', 'w');  // Open PHP output stream for writing CSV data

// Add BOM (Byte Order Mark) for UTF-8 encoding to ensure Excel compatibility
fputs($output, "\xEF\xBB\xBF");  // UTF-8 BOM characters for proper encoding in Excel

// Add CSV column headers as first row
fputcsv($output, ['Amount', 'Source', 'Date', 'Description']);  // Write header row to CSV file

// Loop through each income record and add as data row in CSV
foreach ($incomes as $income) {
    // Format and write each income record as CSV row
    fputcsv($output, [
        '$' . number_format($income['Amount'], 2),  // Format amount with dollar sign and 2 decimal places
        $income['Source'],                          // Income source name as-is
        $income['DateReceived'],                    // Date received in YYYY-MM-DD format
        $income['Description']                      // Income description text
    ]);
}

// Close the output stream
fclose($output);

// Exit script to prevent any additional output that would corrupt the CSV file
exit;
?>